<? 

$smtp_endereco = "mail.superhospedagem.com.br"; // coloque aqui seu endere�o ou ip do servidor SMTP
$seu_email = "suporte@superhospedagem.com.br"; // coloque aqui o endere�o de email que deseja receber as mensagems do formul�rio de contato.

$usuario_smtp = "autenticacao@superhospedagem.com.br"; // coloque aqui seu usu�rio SMTP em geral � o pr�prio email que envia.
$senha_smtp = "minha_senha"; // coloque aqui sua senha para o usu�rio SMTP acima.

$mensagem_sucesso = "Mensagem enviada com Sucesso!!!"; // coloque aqui sua mensagem de sucesso ao envio do formul�rio.


?>